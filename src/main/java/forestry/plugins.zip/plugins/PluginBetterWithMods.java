package forestry.plugins;

import net.minecraft.block.Block;
import net.minecraft.block.CropsBlock;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.IntegerProperty;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;

import forestry.api.core.ForestryAPI;
import forestry.api.farming.IFarmRegistry;
import forestry.api.modules.ForestryModule;
import forestry.api.recipes.RecipeManagers;
import forestry.core.config.Constants;
import forestry.core.fluids.Fluids;
import forestry.farming.logic.ForestryFarmIdentifier;
import forestry.farming.logic.farmables.FarmableDoubleCrop;
import forestry.modules.ForestryModuleUids;

@SuppressWarnings("unused")
@ForestryModule(containerID = ForestryCompatPlugins.ID, moduleID = ForestryModuleUids.BETTER_WITH_MODS, name = "Better With Mods", author = "Nedelosk", url = Constants.URL, unlocalizedDescription = "for.module.betterwithmods.description")
public class PluginBetterWithMods extends CompatPlugin {
	public PluginBetterWithMods() {
		super("Better With Mods", "betterwithmods");
	}

	@Override
	public void registerRecipes() {
		IFarmRegistry farmRegistry = ForestryAPI.farmRegistry;
		int seedAmount = ForestryAPI.activeMode.getIntegerSetting("squeezer.liquid.seed");
		PropertyBool TOP = PropertyBool.create("top");
		IntegerProperty AGE = CropsBlock.AGE;
		ItemStack hempSeed = getItemStack("hemp");
		Block hempCrop = getBlock("hemp");

		if (hempSeed != null && hempCrop != null) {
			BlockState defaultState = hempCrop.getDefaultState();
			BlockState planted = defaultState.with(AGE, 0).with(TOP, false);
			BlockState mature = defaultState.with(AGE, 7).with(TOP, false);
			BlockState topMature = defaultState.with(AGE, 7).with(TOP, true);

			farmRegistry.registerFarmables(ForestryFarmIdentifier.CROPS, new FarmableDoubleCrop(hempSeed, planted, mature, topMature, true));

			RecipeManagers.squeezerManager.addRecipe(10, hempSeed, Fluids.SEED_OIL.getFluid(seedAmount));
		}
	}
}
